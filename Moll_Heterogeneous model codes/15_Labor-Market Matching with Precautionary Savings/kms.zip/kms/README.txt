1) Stationary equilibirum.

   kms.m      -- Main script.
   kmsfun.m   -- Function called by kms.m.
   kms_cali.m -- Finds vacancy cost for given tightness.

2) Transition dynamics

   kms_transition.m -- Main script. Calculates initial/terminal equilibrium as well.
   kmstranfun.m     -- Function called by kms_transition.

